import { connect } from '../config/db/connectMysql.js';

class ProfileModel {

  static async create({user_id, username, first_name, last_name, address, phone_number, email, document_type_id, document_number, birth_date, age, gender, marital_status, education_level, occupation, years_of_experience, monthly_income, photo_url }) {
    const [result] = await connect.query(
        'INSERT INTO profile (username, first_name, last_name, address, email, phone_number, document_type, document_number, birth_date, age, gender, marital_status, education_level, occupation, years_of_experience, monthly_income, photo_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [user_id, username, first_name, last_name, address, phone_number, email, document_type_id, document_number, birth_date, age, gender, marital_status, education_level, occupation, years_of_experience, monthly_income, photo_url]
    );
    return result.insertId;
  }

  
  static async show() {
    
    const [rows] = await connect.query(
      'CALL sp_show_profile()'
    );
    return rows[0];
  }

 
  static async update(id, { user_id, username, first_name, last_name, address, email, phone_number, document_type_id, document_number, birth_date, age, gender, marital_status, education_level, occupation, years_of_experience, monthly_income, photo_url }) {
    const [result] = await connect.query(
        'UPDATE profile SET username = ?, first_name = ?, last_name = ?, address = ?, email = ?, phone_number = ?, document_type = ?, document_number = ?, birth_date = ?, age = ?, gender = ?, marital_status = ?, education_level = ?, occupation = ?, years_of_experience = ?, monthly_income = ?, photo_url = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
      [user_id, username, first_name, last_name, address, email, phone_number, document_type_id, document_number, birth_date, age, gender, marital_status, education_level, occupation, years_of_experience, monthly_income, photo_url, id]
    );
    return result.affectedRows > 0 ? this.findById(id) : null;
  }

  static async delete(id) {
    const [result] = await connect.query(
      'DELETE FROM Profile WHERE id=?',
      [id]
    );
    return result.affectedRows > 0 ? this.findById(id) : null;
  }

  
  static async findById(id) {
    try {
      let sqlQuery = 'SELECT * FROM `Profile` WHERE `id`= ?';
      const [result] = await connect.query(sqlQuery, id);
      return result;
    } catch (error) {
      return [0];
    }

  }
 
}
export default ProfileModel;